/* ---------------------------------------------------------------
   Aurora background (plain WebGL, no Three.js needed)
   Same fragment shader as the "AnoAI" Three.js component, drawn on a
   full-screen canvas behind the pages.

   - Runs only on About / Projects / Contact (paused on the front page
     and when the browser tab is hidden).
   - If WebGL is not available, the page falls back to the static
     image img/bg-meteors.jpg (see css: body.no-webgl).
   Needs: <canvas id="aurora-bg"></canvas> in the page.
---------------------------------------------------------------- */
(function () {
  "use strict";

  /* ---- Settings ---- */
  var RENDER_SCALE = 1;     // 1 = same sharpness as the original Three.js version
  var TIME_SPEED = 0.96;    // original added 0.016 per frame = ~0.96 per second at 60fps
  var CANVAS_OPACITY = 1;   // 0 - 1

  // Very slow devices: if it runs under ~15fps, quality is lowered a little
  // (never below MIN_SCALE) so the page stays usable. Set false to disable.
  var ADAPTIVE = true;
  var MIN_SCALE = 0.6;

  var canvas = document.getElementById("aurora-bg");
  if (!canvas) return;

  var body = document.body;
  var home = document.getElementById("home");
  var reduceMotion = window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var VERTEX = [
    "attribute vec2 position;",
    "void main() { gl_Position = vec4(position, 0.0, 1.0); }"
  ].join("\n");

  var FRAGMENT = [
    "#ifdef GL_FRAGMENT_PRECISION_HIGH",
    "precision highp float;",
    "#else",
    "precision mediump float;",
    "#endif",
    "uniform float iTime;",
    "uniform vec2 iResolution;",
    "#define NUM_OCTAVES 3",
    "",
    "float rand(vec2 n) {",
    "  return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);",
    "}",
    "",
    "float noise(vec2 p) {",
    "  vec2 ip = floor(p);",
    "  vec2 u = fract(p);",
    "  u = u*u*(3.0-2.0*u);",
    "  float res = mix(",
    "    mix(rand(ip), rand(ip + vec2(1.0, 0.0)), u.x),",
    "    mix(rand(ip + vec2(0.0, 1.0)), rand(ip + vec2(1.0, 1.0)), u.x), u.y);",
    "  return res * res;",
    "}",
    "",
    "float fbm(vec2 x) {",
    "  float v = 0.0;",
    "  float a = 0.3;",
    "  vec2 shift = vec2(100.0);",
    "  mat2 rot = mat2(cos(0.5), sin(0.5), -sin(0.5), cos(0.5));",
    "  for (int i = 0; i < NUM_OCTAVES; ++i) {",
    "    v += a * noise(x);",
    "    x = rot * x * 2.0 + shift;",
    "    a *= 0.4;",
    "  }",
    "  return v;",
    "}",
    "",
    "/* tanh is not built in for WebGL1, so we write it ourselves */",
    "vec4 tanh4(vec4 x) {",
    "  vec4 e = exp(2.0 * clamp(x, -10.0, 10.0));",
    "  return (e - 1.0) / (e + 1.0);",
    "}",
    "",
    "void main() {",
    "  vec2 shake = vec2(sin(iTime * 1.2) * 0.005, cos(iTime * 2.1) * 0.005);",
    "  vec2 p = ((gl_FragCoord.xy + shake * iResolution.xy) - iResolution.xy * 0.5) / iResolution.y * mat2(6.0, -4.0, 4.0, 6.0);",
    "  vec2 v;",
    "  vec4 o = vec4(0.0);",
    "",
    "  float f = 2.0 + fbm(p + vec2(iTime * 5.0, 0.0)) * 0.5;",
    "",
    "  for (float i = 0.0; i < 35.0; i++) {",
    "    v = p + cos(i * i + (iTime + p.x * 0.08) * 0.025 + i * vec2(13.0, 11.0)) * 3.5 + vec2(sin(iTime * 3.0 + i) * 0.003, cos(iTime * 3.5 - i) * 0.003);",
    "    float tailNoise = fbm(v + vec2(iTime * 0.5, i)) * 0.3 * (1.0 - (i / 35.0));",
    "    vec4 auroraColors = vec4(",
    "      0.1 + 0.3 * sin(i * 0.2 + iTime * 0.4),",
    "      0.3 + 0.5 * cos(i * 0.3 + iTime * 0.5),",
    "      0.7 + 0.3 * sin(i * 0.4 + iTime * 0.3),",
    "      1.0",
    "    );",
    "    vec4 currentContribution = auroraColors * exp(sin(i * i + iTime * 0.8)) / length(max(v, vec2(v.x * f * 0.015, v.y * 1.5)));",
    "    float thinnessFactor = smoothstep(0.0, 1.0, i / 35.0) * 0.6;",
    "    o += currentContribution * (1.0 + tailNoise * 0.8) * thinnessFactor;",
    "  }",
    "",
    "  /* o can go slightly negative in places; a negative base into pow()",
    "     is undefined in GLSL and is what caused the red/green flashes",
    "     and the growing colour blob seen on some phones/browsers. */",
    "  o = tanh4(pow(max(o, 0.0) / 100.0, vec4(1.6)));",
    "  gl_FragColor = o * 1.5;",
    "}"
  ].join("\n");

  var gl = null, program = null, uTime = null, uRes = null;
  var raf = 0, last = 0, time = 0;
  var scale = RENDER_SCALE;
  var slowTime = 0, slowFrames = 0;

  function fail() {
    body.classList.add("no-webgl");   // static image fallback
    canvas.style.display = "none";
    stop();
  }

  function compile(type, src) {
    var s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      if (window.console) console.warn("Aurora shader error:", gl.getShaderInfoLog(s));
      return null;
    }
    return s;
  }

  function init() {
    gl = canvas.getContext("webgl", { antialias: false, alpha: false }) ||
         canvas.getContext("experimental-webgl");
    if (!gl) { fail(); return false; }

    var vs = compile(gl.VERTEX_SHADER, VERTEX);
    var fs = compile(gl.FRAGMENT_SHADER, FRAGMENT);
    if (!vs || !fs) { fail(); return false; }

    program = gl.createProgram();
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) { fail(); return false; }
    gl.useProgram(program);

    // one big triangle that covers the whole screen
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    var loc = gl.getAttribLocation(program, "position");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    uTime = gl.getUniformLocation(program, "iTime");
    uRes = gl.getUniformLocation(program, "iResolution");
    canvas.style.opacity = CANVAS_OPACITY;
    return true;
  }

  function resize(force) {
    var w = Math.max(2, Math.round(window.innerWidth * scale));
    var h = Math.max(2, Math.round(window.innerHeight * scale));
    // phones change the window height a little when the address bar hides/shows;
    // ignore that so the canvas is not cleared and rebuilt while scrolling
    if (!force && canvas.width === w && Math.abs(canvas.height - h) < 120 * scale) return;
    canvas.width = w;
    canvas.height = h;
    if (gl) { gl.viewport(0, 0, w, h); draw(); }
  }

  function draw() {
    if (!gl) return;
    gl.uniform1f(uTime, time);
    gl.uniform2f(uRes, canvas.width, canvas.height);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  function loop(ts) {
    raf = requestAnimationFrame(loop);
    if (!last) last = ts;
    var raw = (ts - last) / 1000;
    last = ts;
    var dt = Math.min(0.05, raw);
    time += dt * TIME_SPEED;
    draw();

    if (ADAPTIVE && scale > MIN_SCALE && raw > 0 && raw < 0.5) {
      slowTime += raw;
      slowFrames++;
      if (slowTime >= 2) {                       // look at 2 seconds at a time
        var fps = slowFrames / slowTime;
        slowTime = 0; slowFrames = 0;
        if (fps < 15) {
          scale = Math.max(MIN_SCALE, scale * 0.8);
          resize(true);
        }
      }
    }
  }

  function stop() {
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    last = 0; slowTime = 0; slowFrames = 0;
  }

  /* Run only when it can actually be seen:
     not on the front page, and not while the tab is hidden */
  function shouldRun() {
    if (document.hidden) return false;
    if (home && home.classList.contains("active")) return false;
    return true;
  }

  function update() {
    if (!gl) return;
    if (shouldRun()) {
      if (reduceMotion) { time = 12; resize(true); draw(); }
      else if (!raf) { raf = requestAnimationFrame(loop); }
    } else {
      stop();
    }
  }

  if (!init()) return;
  resize(true);

  var resizeTimer = 0;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () { resize(false); }, 150);
  });

  document.addEventListener("visibilitychange", update);

  if (home && window.MutationObserver) {
    new MutationObserver(update).observe(home, { attributes: true, attributeFilter: ["class"] });
  }

  // if the GPU resets the context, switch to the image fallback
  canvas.addEventListener("webglcontextlost", function (e) {
    e.preventDefault();
    gl = null;
    fail();
  });

  update();
})();
