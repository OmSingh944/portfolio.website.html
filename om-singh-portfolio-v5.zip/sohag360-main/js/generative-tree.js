/* ---------------------------------------------------------------
   Generative Tree background (vanilla JS / canvas)
   A tree grows branch by branch, holds, fades away, then a new
   (different) tree grows. Glowing particles float up from the tips.
   Needs: <canvas id="tree-bg"></canvas> in the page.
---------------------------------------------------------------- */
(function () {
  "use strict";

  /* ---- Settings (same knobs as the React component's props) ---- */
  var SETTINGS = {
    speed: 1,           // 0 - 3       animation / growth speed
    size: 1,            // 0.65 - 1.5  tree size
    particleAmount: 1,  // 0 - 2       amount of floating particles
    opacity: 0.6,       // 0.05 - 1    overall opacity of the tree
    hue: 0,             // -180 - 180  rotate colours (base colour is blue)
    saturation: 1,      // 0 - 2
    brightness: 1       // 0.35 - 1.8
  };

  var BASE_HUE = 205;      // blue, matches the portfolio's blue skin
  var MAX_DEPTH = 9;       // how many times branches split
  var HOLD_SECONDS = 6;    // how long the full tree stays on screen
  var FADE_SECONDS = 3;    // fade-out time
  var WAIT_SECONDS = 0.8;  // pause before the next tree

  var canvas = document.getElementById("tree-bg");
  if (!canvas || !canvas.getContext) return;
  var ctx = canvas.getContext("2d");

  var reduceMotion = window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var W = 0, H = 0, dpr = 1;
  var tree = null;
  var particles = [];
  var clock = 0;           // seconds, drives the gentle sway
  var state = { phase: "grow", growth: 0, timer: 0, alpha: 1 };
  var raf = 0, last = 0;

  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function rand(a, b) { return a + Math.random() * (b - a); }

  /* ---- CSS filter for opacity / hue / saturation / brightness ---- */
  function applyLook() {
    canvas.style.opacity = clamp(SETTINGS.opacity, 0.05, 1);
    var h = clamp(SETTINGS.hue, -180, 180);
    var s = clamp(SETTINGS.saturation, 0, 2);
    var b = clamp(SETTINGS.brightness, 0.35, 1.8);
    canvas.style.filter = (h === 0 && s === 1 && b === 1) ? "" :
      "hue-rotate(" + h + "deg) saturate(" + s + ") brightness(" + b + ")";
  }

  /* ---- Build a random tree (whole structure up front) ---- */
  function buildTree() {
    var unit = Math.min(H, W * 1.4) * clamp(SETTINGS.size, 0.65, 1.5);
    var rate = unit * 0.11;      // growth speed in px per second
    var nodes = [];

    function make(depth, len, rel, start) {
      var dur = len / rate;
      var light = 34 + depth * 3.6;
      var node = {
        depth: depth,
        len: len,
        rel: rel,
        start: start,
        dur: dur,
        width: Math.max(0.7, unit * 0.013 * Math.pow(0.72, depth)),
        bend: rand(-0.12, 0.12),
        phase: rand(0, 6.28),
        color: "hsl(" + (BASE_HUE + depth * 5) + ",70%," + light + "%)",
        glow: "hsl(" + (BASE_HUE + depth * 5) + ",90%,60%)",
        children: [],
        p: 0, tx: 0, ty: 0
      };
      nodes.push(node);

      var canSplit = depth < MAX_DEPTH && !(depth > 3 && Math.random() < 0.12);
      if (canSplit) {
        var n = (depth > 2 && Math.random() < 0.2) ? 3 : 2;
        for (var i = 0; i < n; i++) {
          var spread = (n === 2) ? (i === 0 ? -1 : 1) : (i - 1);
          var childRel = spread * rand(0.28, 0.6) + rand(-0.1, 0.1);
          node.children.push(make(depth + 1, len * rand(0.7, 0.82), childRel, start + dur));
        }
      }
      return node;
    }

    var root = make(0, unit * 0.2, rand(-0.05, 0.05), 0);
    var total = 0;
    for (var i = 0; i < nodes.length; i++) {
      total = Math.max(total, nodes[i].start + nodes[i].dur);
    }
    return { root: root, nodes: nodes, total: total, unit: unit };
  }

  function newTree() {
    tree = buildTree();
    state.phase = "grow";
    state.growth = reduceMotion ? tree.total : 0;
    state.timer = 0;
    state.alpha = 1;
  }

  /* ---- Particles ---- */
  function buildParticles() {
    var count = Math.round(50 * clamp(SETTINGS.particleAmount, 0, 2));
    particles = [];
    for (var i = 0; i < count; i++) {
      particles.push({ x: 0, y: 0, vx: 0, vy: 0, life: -rand(0, 5), max: 5, r: 1, off: 0 });
    }
  }

  function spawnParticle(p) {
    var nodes = tree.nodes, n = null;
    for (var t = 0; t < 8; t++) {
      var c = nodes[(Math.random() * nodes.length) | 0];
      if (c.p > 0 && c.depth >= 2) { n = c; break; }
    }
    if (!n) { p.life = -rand(0.2, 1); return; }
    var k = tree.unit / 600;
    p.x = n.tx + rand(-4, 4);
    p.y = n.ty + rand(-4, 4);
    p.vx = rand(-10, 10) * k;
    p.vy = rand(-26, -8) * k;
    p.life = 0;
    p.max = rand(3, 7);
    p.r = rand(0.8, 2.2);
    p.off = rand(-15, 25);
  }

  function stepParticles(dt) {
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      if (p.life < 0) {
        p.life += dt;
        if (p.life >= 0) spawnParticle(p);
        continue;
      }
      p.life += dt;
      p.x += (p.vx + Math.sin(clock * 1.3 + i) * 6) * dt;
      p.y += p.vy * dt;
      if (p.life >= p.max) p.life = -rand(0, 1.5);
    }
  }

  /* ---- Update ---- */
  function step(dt) {
    var s = clamp(SETTINGS.speed, 0, 3);
    var d = dt * s;
    clock += d;

    if (state.phase === "grow") {
      state.growth += d;
      if (state.growth >= tree.total) { state.phase = "hold"; state.timer = 0; }
    } else if (state.phase === "hold") {
      state.timer += d;
      if (state.timer >= HOLD_SECONDS) { state.phase = "fade"; state.timer = 0; }
    } else if (state.phase === "fade") {
      state.timer += d;
      state.alpha = clamp(1 - state.timer / FADE_SECONDS, 0, 1);
      if (state.timer >= FADE_SECONDS) { state.phase = "wait"; state.timer = 0; state.alpha = 0; }
    } else if (state.phase === "wait") {
      state.timer += d;
      if (state.timer >= WAIT_SECONDS) newTree();
    }
    stepParticles(d);
  }

  /* ---- Draw ---- */
  function drawNode(node, x, y, parentAngle) {
    var p = clamp((state.growth - node.start) / node.dur, 0, 1);
    node.p = p;
    if (p <= 0) return;

    var sway = Math.sin(clock * 0.7 + node.phase + node.depth * 0.6) *
               0.012 * (1 + node.depth * 0.4);
    var a = parentAngle + node.rel + sway;
    var len = node.len;

    var x2 = x + Math.cos(a) * len;
    var y2 = y + Math.sin(a) * len;
    var mx = (x + x2) / 2 + Math.cos(a + Math.PI / 2) * node.bend * len;
    var my = (y + y2) / 2 + Math.sin(a + Math.PI / 2) * node.bend * len;

    // partial curve while the branch is still growing
    var q1x = x + (mx - x) * p, q1y = y + (my - y) * p;
    var r1x = mx + (x2 - mx) * p, r1y = my + (y2 - my) * p;
    var tx = q1x + (r1x - q1x) * p, ty = q1y + (r1y - q1y) * p;
    node.tx = tx; node.ty = ty;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(q1x, q1y, tx, ty);

    // soft glow pass, then the sharp core
    ctx.globalAlpha = 0.09 * state.alpha;
    ctx.strokeStyle = node.glow;
    ctx.lineWidth = node.width * 2.4;
    ctx.stroke();
    ctx.globalAlpha = state.alpha;
    ctx.strokeStyle = node.color;
    ctx.lineWidth = node.width;
    ctx.stroke();

    if (p >= 1) {
      if (node.children.length === 0) {
        // glowing bud on the tips
        var pulse = 1.6 + Math.sin(clock * 2 + node.phase) * 0.6;
        ctx.globalAlpha = 0.9 * state.alpha;
        ctx.fillStyle = "hsl(" + (BASE_HUE + 10) + ",90%,72%)";
        ctx.beginPath();
        ctx.arc(x2, y2, pulse, 0, 6.2832);
        ctx.fill();
      }
      for (var i = 0; i < node.children.length; i++) {
        drawNode(node.children[i], x2, y2, a);
      }
    }
  }

  function drawParticles() {
    ctx.globalCompositeOperation = "lighter";
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      if (p.life < 0) continue;
      var f = Math.sin(Math.PI * (p.life / p.max));
      var al = clamp(f, 0, 1) * 0.85 * state.alpha;
      if (al <= 0.01) continue;
      ctx.fillStyle = "hsl(" + (BASE_HUE + p.off) + ",85%,68%)";
      ctx.globalAlpha = al * 0.18;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 3.2, 0, 6.2832); ctx.fill();
      ctx.globalAlpha = al;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832); ctx.fill();
    }
    ctx.globalCompositeOperation = "source-over";
  }

  function render() {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    if (state.alpha <= 0.001) return;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    drawNode(tree.root, W / 2, H + 4, -Math.PI / 2);
    drawParticles();
    ctx.globalAlpha = 1;
  }

  /* ---- Loop ---- */
  function loop(ts) {
    raf = requestAnimationFrame(loop);
    if (!last) last = ts;
    var dt = Math.min(0.05, (ts - last) / 1000);
    last = ts;
    step(dt);
    render();
  }

  function start() {
    if (reduceMotion || raf) return;
    last = 0;
    raf = requestAnimationFrame(loop);
  }

  function stop() {
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
  }

  /* ---- Sizing ---- */
  function resize(force) {
    var nw = window.innerWidth, nh = window.innerHeight;
    var bigChange = force || nw !== W || Math.abs(nh - H) > 150;
    W = nw; H = nh;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    if (bigChange || !tree) { newTree(); buildParticles(); }
    if (reduceMotion) render();
  }

  var resizeTimer = 0;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () { resize(false); }, 200);
  });

  document.addEventListener("visibilitychange", function () {
    if (document.hidden) stop(); else start();
  });

  applyLook();
  resize(true);
  start();
})();
